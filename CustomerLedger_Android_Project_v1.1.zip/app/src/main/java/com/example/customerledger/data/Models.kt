package com.example.customerledger.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val mobile: String,
    val address: String,
    val notes: String = ""
)

@Entity(
    tableName = "transactions",
    foreignKeys = [ForeignKey(
        entity = Customer::class,
        parentColumns = ["id"],
        childColumns = ["customerId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("customerId")]
)
data class LedgerTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val type: String, // CREDIT or DEBIT
    val amount: Double,
    val date: Long = System.currentTimeMillis(),
    val note: String = ""
)

@Dao
interface CustomerDao {
    @Query("""
        SELECT * FROM customers
        WHERE name LIKE '%' || :q || '%'
           OR mobile LIKE '%' || :q || '%'
           OR address LIKE '%' || :q || '%'
        ORDER BY name COLLATE NOCASE
    """)
    fun search(q: String): Flow<List<Customer>>

    @Query("SELECT * FROM customers WHERE id = :id LIMIT 1")
    suspend fun get(id: Long): Customer?

    @Query("SELECT * FROM customers ORDER BY name COLLATE NOCASE")
    suspend fun all(): List<Customer>

    @Insert
    suspend fun insert(customer: Customer): Long

    @Update
    suspend fun update(customer: Customer)

    @Delete
    suspend fun delete(customer: Customer)
}

@Dao
interface LedgerDao {
    @Query("SELECT * FROM transactions WHERE customerId = :customerId ORDER BY date DESC, id DESC")
    fun transactions(customerId: Long): Flow<List<LedgerTransaction>>

    @Insert
    suspend fun insert(transaction: LedgerTransaction)

    @Query("SELECT * FROM transactions ORDER BY date ASC, id ASC")
    suspend fun all(): List<LedgerTransaction>

    @Query("""
        SELECT COALESCE(SUM(CASE WHEN type='CREDIT' THEN amount ELSE 0 END),0)
        - COALESCE(SUM(CASE WHEN type='DEBIT' THEN amount ELSE 0 END),0)
        FROM transactions WHERE customerId = :customerId
    """)
    fun balance(customerId: Long): Flow<Double>
}

@Database(entities = [Customer::class, LedgerTransaction::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun customerDao(): CustomerDao
    abstract fun ledgerDao(): LedgerDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: android.content.Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "customer_ledger.db"
                ).build().also { INSTANCE = it }
            }
    }
}
