# Customer Ledger Android App v1.1

Features:
- Offline Room database
- Customer name, mobile, address, notes
- Search by name/mobile/address
- Add/edit/delete customers
- Credit/debit transactions
- Automatic balance and transaction history
- Dashboard
- CSV export/share
- JSON backup/share
- Suitable for 10,000+ customer records

Open the project in Android Studio and run the app on an Android device or emulator.
