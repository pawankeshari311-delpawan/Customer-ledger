package com.example.customerledger

import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.customerledger.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class LedgerViewModel(private val db: AppDatabase) : ViewModel() {
    var query by mutableStateOf("")
    val customers = db.customerDao().search(query).stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    fun addCustomer(name:String, mobile:String, address:String, notes:String) {
        viewModelScope.launch { db.customerDao().insert(Customer(name=name, mobile=mobile, address=address, notes=notes)) }
    }
    fun addTransaction(customerId:Long, type:String, amount:Double, note:String) {
        viewModelScope.launch { db.ledgerDao().insert(LedgerTransaction(customerId=customerId,type=type,amount=amount,note=note)) }
    }
    fun balance(id:Long) = db.ledgerDao().balance(id)
    fun transactions(id:Long) = db.ledgerDao().transactions(id)

    suspend fun exportCsv(context: Context): File {
        val cs=db.customerDao().all(); val ts=db.ledgerDao().all()
        val f=File(context.cacheDir,"customer_ledger.csv")
        f.printWriter().use { out ->
            out.println("Customer ID,Name,Mobile,Address,Transaction ID,Date,Type,Amount,Note")
            val by=ts.groupBy{it.customerId}
            for(c in cs) for(t in by[c.id].orEmpty()) {
                fun q(x:String)="\""+x.replace("\"","\"\"")+"\""
                val d=SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(Date(t.date))
                out.println(listOf(c.id,q(c.name),q(c.mobile),q(c.address),t.id,d,t.type,t.amount,q(t.note)).joinToString(","))
            }
        }; return f
    }

    suspend fun backupJson(context: Context): File {
        val root=JSONObject(); val cs=db.customerDao().all(); val ts=db.ledgerDao().all()
        val ca=JSONArray(); cs.forEach{c->ca.put(JSONObject().apply{put("id",c.id);put("name",c.name);put("mobile",c.mobile);put("address",c.address);put("notes",c.notes)})}
        val ta=JSONArray(); ts.forEach{t->ta.put(JSONObject().apply{put("id",t.id);put("customerId",t.customerId);put("type",t.type);put("amount",t.amount);put("date",t.date);put("note",t.note)})}
        root.put("customers",ca); root.put("transactions",ta)
        val f=File(context.cacheDir,"customer_ledger_backup.json"); f.writeText(root.toString()); return f
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDatabase.get(this)
        setContent { CustomerLedgerApp(db) }
    }
}

@Composable
fun CustomerLedgerApp(db: AppDatabase) {
    val vm = remember { LedgerViewModel(db) }
    var selected by remember { mutableStateOf<Customer?>(null) }
    var addingCustomer by remember { mutableStateOf(false) }
    var addingTransaction by remember { mutableStateOf(false) }

    MaterialTheme {
        if (selected == null) {
            CustomerListScreen(
                vm = vm,
                onSelect = { selected = it },
                onAdd = { addingCustomer = true }
            )
        } else {
            CustomerScreen(
                vm = vm,
                customer = selected!!,
                onBack = { selected = null },
                onAddTransaction = { addingTransaction = true }
            )
        }

        if (addingCustomer) {
            AddCustomerDialog(
                onDismiss = { addingCustomer = false },
                onSave = { n,m,a,no -> vm.addCustomer(n,m,a,no); addingCustomer=false }
            )
        }
        if (addingTransaction && selected != null) {
            AddTransactionDialog(
                onDismiss = { addingTransaction = false },
                onSave = { type,amount,note ->
                    vm.addTransaction(selected!!.id,type,amount,note)
                    addingTransaction=false
                }
            )
        }
    }
}

fun shareFile(context: Context, file: File, mime: String) {
    val uri = FileProvider.getUriForFile(
        context,
        context.packageName + ".fileprovider",
        file
    )
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = mime
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Share file"))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerListScreen(vm: LedgerViewModel, onSelect:(Customer)->Unit, onAdd:()->Unit) {
    val customers by vm.customers.collectAsState()
    Scaffold(
        topBar = { TopAppBar(title={Text("Customer Ledger")}) },
        floatingActionButton = { FloatingActionButton(onClick=onAdd){ Text("+") } }
    ) { pad ->
        Column(Modifier.padding(pad).padding(12.dp)) {
            OutlinedTextField(
                value=vm.query, onValueChange={vm.query=it},
                modifier=Modifier.fillMaxWidth(),
                label={Text("Search name, mobile or address")},
                singleLine=true
            )
            Spacer(Modifier.height(10.dp))
            Text("${customers.size} customer(s)", style=MaterialTheme.typography.labelMedium)
            LazyColumn {
                items(customers, key={it.id}) { c ->
                    Card(Modifier.fillMaxWidth().padding(vertical=4.dp).clickable{onSelect(c)}) {
                        Column(Modifier.padding(14.dp)) {
                            Text(c.name, style=MaterialTheme.typography.titleMedium)
                            if(c.mobile.isNotBlank()) Text(c.mobile)
                            if(c.address.isNotBlank()) Text(c.address, style=MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerScreen(vm:LedgerViewModel, customer:Customer, onBack:()->Unit, onAddTransaction:()->Unit) {
    val balance by vm.balance(customer.id).collectAsState(0.0)
    val txns by vm.transactions(customer.id).collectAsState(emptyList())
    Scaffold(
        topBar={TopAppBar(title={Text(customer.name)}, navigationIcon={
            TextButton(onClick=onBack){Text("Back")}
        })},
        floatingActionButton={FloatingActionButton(onClick=onAddTransaction){Text("+")}}
    ){ pad ->
        Column(Modifier.padding(pad).padding(16.dp)) {
            Text("Mobile: ${customer.mobile}")
            Text("Address: ${customer.address}")
            if(customer.notes.isNotBlank()) Text("Notes: ${customer.notes}")
            Spacer(Modifier.height(12.dp))
            Card(Modifier.fillMaxWidth()){
                Column(Modifier.padding(16.dp)){
                    Text("Current Balance", style=MaterialTheme.typography.labelLarge)
                    Text("₹ ${"%.2f".format(balance)}", style=MaterialTheme.typography.headlineMedium)
                    Text(if(balance>=0) "Credit balance" else "Debit balance")
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("Transaction History", style=MaterialTheme.typography.titleMedium)
            LazyColumn {
                items(txns, key={it.id}) { t ->
                    val date=SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(t.date))
                    ListItem(
                        headlineContent={Text("${t.type}: ₹ ${"%.2f".format(t.amount)}")},
                        supportingContent={Text("$date${if(t.note.isNotBlank()) " • ${t.note}" else ""}")}
                    )
                    HorizontalDivider()
                }
            }
        }
    }
}

@Composable
fun AddCustomerDialog(onDismiss:()->Unit,onSave:(String,String,String,String)->Unit) {
    var name by remember{mutableStateOf("")}; var mobile by remember{mutableStateOf("")}
    var address by remember{mutableStateOf("")}; var notes by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=onDismiss, title={Text("Add Customer")},
        text={Column{
            OutlinedTextField(name,{name=it},label={Text("Name")},singleLine=true)
            OutlinedTextField(mobile,{mobile=it},label={Text("Mobile")},singleLine=true)
            OutlinedTextField(address,{address=it},label={Text("Address")})
            OutlinedTextField(notes,{notes=it},label={Text("Notes")})
        }},
        confirmButton={TextButton(enabled=name.isNotBlank(),onClick={onSave(name,mobile,address,notes)}){Text("Save")}},
        dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})
}

@Composable
fun AddTransactionDialog(onDismiss:()->Unit,onSave:(String,Double,String)->Unit) {
    var type by remember{mutableStateOf("CREDIT")}; var amount by remember{mutableStateOf("")}; var note by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=onDismiss,title={Text("Add Transaction")},
        text={Column{
            Row{Button(onClick={type="CREDIT"}){Text("Credit")}; Spacer(Modifier.width(8.dp)); Button(onClick={type="DEBIT"}){Text("Debit")}}
            OutlinedTextField(amount,{amount=it},label={Text("Amount")},singleLine=true)
            OutlinedTextField(note,{note=it},label={Text("Note")})
        }},
        confirmButton={TextButton(enabled=(amount.toDoubleOrNull() ?: 0.0)>0,onClick={onSave(type,amount.toDouble(),note)}){Text("Save")}},
        dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})
}
